require("dotenv").config();
const bitcoin = require('bitcoinjs-lib');
const coingeckoApi = require("coingecko-api");
const { Client, Intents } = require("discord.js");
const client = new Client({
	intents: [
		Intents.FLAGS.GUILDS,
		Intents.FLAGS.GUILD_MESSAGES
	]
});

client.once("ready", () => {
	console.log("Avadako is online.");
});

client.on("messageCreate", message => {
	if (message.content.startsWith(">")) {
		if (message.content.substring(1) === "ping") {
			message.reply("Pong!!!!");
		}
	}
});






client.on("messageCreate", message => {
	if (message.content.startsWith(">")) {
		if (message.content.substring(1) === "price") {
			const url = "https://api.coindesk.com/v1/bpi/currentprice.json";
			const request = require("request");
			request(url, function (error, response, body) {
				if (!error && response.statusCode == 200) {
					const data = JSON.parse(body);
					message.reply(data.bpi.USD.rate);
				}
			});
		}
	}
});











client.login(process.env.TOKEN);
